﻿using UnityEngine.UI;
using UnityEngine;

public class Score : MonoBehaviour
{
    public Transform meta;
    public Transform player;
    public Text scoreText;

    void Start()
    {
        scoreText.text = (meta.position.z - player.position.z).ToString("0");
    }

    // Update is called once per frame
    void Update()
    {
        if (meta.position.z - player.position.z > 0)
        {
            scoreText.text = (meta.position.z - player.position.z).ToString("0");
        }
        else
            scoreText.text = "0";

    }
}
