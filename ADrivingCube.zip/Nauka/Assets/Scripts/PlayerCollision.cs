﻿
using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public PlayerMove movement;
    
    void Start()
    {
        Physics.IgnoreLayerCollision(9, 10);
    }

    void OnCollisionEnter(Collision collisionInfo)
    { 
        if(collisionInfo.collider.tag == "Obstacle")
        {
            Debug.Log("I hit something");
            movement.enabled = false;
            FindObjectOfType<GameManager>().EndGame();

        }
    }
}
