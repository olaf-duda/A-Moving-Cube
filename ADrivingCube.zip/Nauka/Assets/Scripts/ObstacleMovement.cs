﻿
using UnityEngine;

public class ObstacleMovement : MonoBehaviour
{

    public Rigidbody rb;
    public Transform obstacle;
    public float Speed = 10f;
    public float dif = -1;


    // Update is called once per frame
    void Update()
    {

        GetComponent<Rigidbody>().velocity = new Vector3(1, 0,0) * Speed* dif;


    }
    void OnCollisionEnter(Collision collisionInfo)
    {
        dif = dif * (-1);
    }
}
