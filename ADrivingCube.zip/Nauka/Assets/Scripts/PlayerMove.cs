﻿
using UnityEngine;

public class PlayerMove : MonoBehaviour
{

    public Rigidbody rb;

    public float ForwForce = 2000f;
    public float LRForce = 500f;


    // Update is called once per frame
    void FixedUpdate()
    {
        // Add a forward force
        rb.AddForce(0 , 0, ForwForce * Time.deltaTime);

        if (Input.GetKey("d") )
        {
            rb.AddForce(LRForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
        }
        if (Input.GetKey("a"))
        {
            rb.AddForce(-LRForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
        }

        if(rb.position.y <= -1f)
        {
            FindObjectOfType<GameManager>().EndGame();
        }

    }
}
